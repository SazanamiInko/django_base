from django.apps import AppConfig


class Pg003QueryConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "pg003_query"
