from django.apps import AppConfig


class Pg005SmarturlConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "pg005_smarturl"
